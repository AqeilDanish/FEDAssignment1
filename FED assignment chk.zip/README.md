# FEDAssignment1
This is my FED assignment 1 project.

FED Assignment 

Website: Travel, Good to Fly (telegram chat) 

Purpose: The purpose of the telegram chat is to provide news and updates for members on flight tickets, travel updates and travel tips for any asian countries. My website will serve as a travel news website for the telegram chat. It will provide the same news updates as well as being able to see the flight tickets and book hotels too. It will act similarly to websites such as Trip.com, TripAdvisor and Booking.com. 

Audience: The users of the telegram chat and anyone who wants any news on travelling. 

Design intent: The website should be responsive and functional to all devices. The website will include clear directionary for users to be able to navigate well. The website will follow website designs such as mothership for the news and other travel websites so as to not confuse the users and make it easier for them to navigate. 

Layout of website: 
   --> features to inculde:
	    - scrolling pages for the different countries and news.
        - search bar for users to enter the countries they want to visit.
	    - Seach engine for users 
        - telegram chat for live updates

    --> Content to include:
        - news from the telegram chat
        - pictures entice users and make it more readable 
        - flight deals and hotel deals for users
        - travel itinerary for anyone to follow